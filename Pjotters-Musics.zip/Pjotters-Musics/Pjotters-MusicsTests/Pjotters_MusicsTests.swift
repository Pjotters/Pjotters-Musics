//
//  Pjotters_MusicsTests.swift
//  Pjotters-MusicsTests
//
//  Created by Pieter Oosterling on 06/12/2024.
//

#if canImport(XCTest)
import XCTest
#endif

@testable import Pjotters_Musics

final class Pjotters_MusicsTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Setup code hier
    }
    
    override func tearDown() {
        // Cleanup code hier
        super.tearDown()
    }

    func testExample() throws {
        // Test implementatie hier
        XCTAssert(true)
    }
}
