//
//  Pjotters_MusicsApp.swift
//  Pjotters-Musics
//
//  Created by Pieter Oosterling on 06/12/2024.
//

import SwiftUI

@main
struct Pjotters_MusicsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
