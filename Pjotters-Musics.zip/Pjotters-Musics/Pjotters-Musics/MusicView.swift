import SwiftUI

struct MusicView: View {
    @State private var isLoading = true
    
    var body: some View {
        NavigationView {
            if isLoading {
                LoadingView()
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            isLoading = false
                        }
                    }
            } else {
                HomeView()
            }
        }
    }
}

struct LoadingView: View {
    @State private var rotation: Double = 0
    @State private var scale: CGFloat = 1.0
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Pjotters Musics")
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundColor(.primary)
                .shadow(radius: 2)
            
            Text("Bij Pjotters Musics zorgen wij het best voor onze artiesten!")
                .font(.title3)
                .fontWeight(.medium)
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .padding(.horizontal)
            
            Image(uiImage: #imageLiteral(resourceName: "Pjotters-Shop 2.jpg"))
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 300)
            
            Text("Made by Pjotters-Shop")
                .font(.caption)
                .foregroundColor(.secondary)
                
            Spacer()
            
            Text("A company of The PjottersChain")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

struct ArtistLoginView: View {
    @State private var password = ""
    @State private var isUnlocked = false
    @State private var showError = false
    
    var body: some View {
        Group {
            if isUnlocked {
                ScrollView {
                    VStack(spacing: 30) {
                        Text("Pjotters Musics")
                            .font(.system(size: 40, weight: .bold, design: .rounded))
                        
                        Text("Bij Pjotters Musics zorgen wij het best voor onze artiesten!")
                            .font(.title3)
                            .multilineTextAlignment(.center)
                        
                        VStack(alignment: .leading, spacing: 20) {
                            Text("Ons Verhaal")
                                .font(.title2)
                                .fontWeight(.bold)
                            
                            Text("We zijn begon bij niks, namelijk een MacBook een HYPEX microfoon en Bandgarage. Een jaar later zijn we gaan uitbreiden en namen we onze eerste personeels leden aan. We gingen door met creëren van muziek en het creëren van artiesten. We zijn nu uitgegroeid tot een groot bedrijf met meerder klanten per dag en meerdere aanmeldingen per dag.")
                                .foregroundColor(.secondary)
                            
                            Text("Met vriendelijke groet:\nPieter Oosterling,\nPresident van Pjotters Musics")
                                .fontWeight(.medium)
                        }
                        
                        VStack(spacing: 20) {
                            Text("Upload nu jouw Muziek")
                                .font(.title)
                                .fontWeight(.bold)
                            
                            VStack(alignment: .leading, spacing: 15) {
                                TextField("Naam of Pjotters-code", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                
                                TextField("Pjotters-mail", text: .constant(""))
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                
                                TextEditor(text: .constant(""))
                                    .frame(height: 100)
                                    .border(Color.gray.opacity(0.2))
                                
                                Button("Uploaden als artiest") {
                                    // Upload action
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(10)
                        }
                        
                        Spacer()
                        
                        Text("A company of The PjottersChain")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                }
            } else {
                VStack(spacing: 20) {
                    Text("Voer het wachtwoord in")
                        .font(.title2)
                    
                    SecureField("Wachtwoord", text: $password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    
                    Button("Login") {
                        if password == "7612" {
                            isUnlocked = true
                        } else {
                            showError = true
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .alert("Incorrect wachtwoord", isPresented: $showError) {
                        Button("OK", role: .cancel) {}
                    }
                    
                    Spacer()
                    
                    Text("A company of The PjottersChain")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                .padding()
            }
        }
        .navigationTitle("Artiesten-inlog")
    }
}

struct PjottersLidView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Pjotters-lid")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Deze optie komt binnenkort naar de app. Voor nu kan je de webvariant gebruiken.")
                .multilineTextAlignment(.center)
                .padding()
            
            Link("Ga naar website", destination: URL(string: "https://pjottersmusics000webhostapp.wordpress.com")!)
                .buttonStyle(.borderedProminent)
                
            Spacer()
            
            Text("A company of The PjottersChain")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

struct PjottersLidmaatschappenView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Pjotters-Lidmaatschappen")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Deze optie komt binnenkort naar de app. Voor nu kan je de webvariant gebruiken.")
                .multilineTextAlignment(.center)
                .padding()
            
            Link("Ga naar website", destination: URL(string: "https://pjottersmusics000webhostapp.wordpress.com")!)
                .buttonStyle(.borderedProminent)
                
            Spacer()
            
            Text("A company of The PjottersChain")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

struct PjottersPremiumView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Pjotters-Premium")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Deze optie komt binnenkort naar de app. Voor nu kan je de webvariant gebruiken.")
                .multilineTextAlignment(.center)
                .padding()
            
            Link("Ga naar website", destination: URL(string: "https://pjottersmusics000webhostapp.wordpress.com")!)
                .buttonStyle(.borderedProminent)
                
            Spacer()
            
            Text("A company of The PjottersChain")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

struct PremiumLoginView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Premium-inlog")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Deze optie komt binnenkort naar de app. Voor nu kan je de webvariant gebruiken.")
                .multilineTextAlignment(.center)
                .padding()
            
            Link("Ga naar website", destination: URL(string: "https://pjottersmusics000webhostapp.wordpress.com")!)
                .buttonStyle(.borderedProminent)
                
            Spacer()
            
            Text("A company of The PjottersChain")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

struct PjottersMusicMainView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Pjotters Musics")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Deze optie komt binnenkort naar de app. Voor nu kan je de webvariant gebruiken.")
                .multilineTextAlignment(.center)
                .padding()
            
            Link("Ga naar website", destination: URL(string: "https://pjottersmusics000webhostapp.wordpress.com")!)
                .buttonStyle(.borderedProminent)
                
            Spacer()
            
            Text("A company of The PjottersChain")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

struct InfoSection: View {
    let title: String
    let content: String
    let icon: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: icon)
                    .font(.title2)
                Text(title)
                    .font(.title2)
                    .fontWeight(.bold)
            }
            Text(content)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}

struct HomeView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                Text("Pjotters Musics")
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)
                
                VStack(spacing: 15) {
                    Text("Pagina's")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    NavigationLink(destination: ArtistLoginView()) {
                        Text("Artiesten-inlog")
                            .foregroundColor(.blue)
                    }
                    
                    NavigationLink(destination: PjottersLidView()) {
                        Text("Pjotters-lid")
                            .foregroundColor(.blue)
                    }
                    
                    NavigationLink(destination: PjottersLidmaatschappenView()) {
                        Text("Pjotters-Lidmaatschappen")
                            .foregroundColor(.blue)
                    }
                    
                    NavigationLink(destination: PjottersPremiumView()) {
                        Text("Pjotters-Premium")
                            .foregroundColor(.blue)
                    }
                    
                    NavigationLink(destination: PremiumLoginView()) {
                        Text("Premium-inlog")
                            .foregroundColor(.blue)
                    }
                    
                    NavigationLink(destination: PjottersMusicMainView()) {
                        Text("Pjotters Musics")
                            .foregroundColor(.blue)
                    }
                }
                
                InfoSection(title: "Platenlabel",
                          content: "Pjotters Musics is ook een platenlabel, dat wil zeggen dat het nummer op neemt voor de artiest en de beat maakt met: Pieter Oosterling. De Site die we daarvoor gebruiken is Garageband. Wij maken ook de cover van het nummer, naar keuzen van de artiest.",
                          icon: "music.note")
                
                InfoSection(title: "Distributeur",
                          content: "Pjotters Musics distrubeert ook muziek naar Spotify en/of Apple music. Als je het via ons laat doen zijn u gegevens 100% beschermd en verliest u niet u recht van artiest. We hebben al van verschillende artiesten muziek online staan op spotify.",
                          icon: "square.and.arrow.up")
                
                VStack(spacing: 20) {
                    StatsView(value: "5", title: "Years of experience")
                    StatsView(value: "5000+", title: "Gebruikers")
                    StatsView(value: "87%", title: "Customer satisfaction")
                    StatsView(value: "€10", title: "Per week inkomsten voor artiest gemiddeld")
                }
                
                ContactSection()
                
                Text("A company of The PjottersChain")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            .padding()
        }
    }
}

struct StatsView: View {
    let value: String
    let title: String
    
    var body: some View {
        VStack {
            Text(value)
                .font(.title)
                .fontWeight(.bold)
            Text(title)
                .foregroundColor(.secondary)
        }
    }
}

struct ContactSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Neem contact op")
                .font(.title2)
                .fontWeight(.bold)
            
            Text("Mail: pjottersmusics@gmail.com")
            Text("Locatie: Nieuwe Plantage 87, Delft")
            
            Text("Openingstijden")
                .font(.headline)
                .padding(.top)
            Text("maandag-vrijdag")
            Text("9.00-17.00")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct MusicView_Previews: PreviewProvider {
    static var previews: some View {
        MusicView()
            .preferredColorScheme(.light)
        MusicView()
            .preferredColorScheme(.dark)
    }
}
